import { PrismaClient } from "@prisma/client";


const prisma = new PrismaClient();

async function main() {
  console.log('Iniciando o seed...')
  // Criação de usuarios
  const userA = await prisma.user.create({
    data: {
      nickname: 'Ana Carol',
      username: 'ana.carol',
      email: 'ana@email.com',
      password: 'senha123',
      phone: '11999990000',
      photoProfile: '',
      description: 'Viajante internacional, adoro ir para diversos paises',
    }
  })
  const userB = await prisma.user.create({
    data: {
      nickname: 'Beto Silva',
      username: 'beto.silva',
      email: 'beto@email.com',
      password: '456senha',
      phone: '11922223333',
      photoProfile: '',
      description: 'Intusiasta de turismo florestal',
    }
  })
  // Conexão entre usuários
  await prisma.connection.create({
    data: {
      followUserId: userA.id,
      followingUserId: userB.id,
      state: 'accepted'
    }
  })
  // Tags para uso de posts
  const [tagA, tagB] = await Promise.all([
    prisma.tag.create({ data: { name: 'viagem' } }),
    prisma.tag.create({ data: { name: 'natureza' } })
  ])
  // Criando um post do usuário Ana
  const post = await prisma.post.create({
    data: {
      description: 'Mais uma viagem repleta de emoções',
      privacity: false,
      likeNumber: 0,
      user: { connect: { id: userA.id } },
      components: {
        create: [
          {
            order: 1,
            type: 'TEXT',
            content: {
              create: {
                content: 'Para todos que desejam um lugar completo de aventuraa, envolto na natureza, aqui é esse lugar!'
              }
            }
          },
          {
            order: 2,
            type: 'PHOTO',
            content: {
              create: {
                url: 'https://exemplo.com/imagem.png',
                caption: 'Reserva Florestal'
              }
            }
          }
        ]
      },
      postTags: {
        create: [
          { tag: { connect: { id: tagA.id } } },
          { tag: { connect: { id: tagB.id } } }
        ]
      },
      locations: {
        create: {
          country: 'Brasil',
          region: 'Norte',
          city: 'Manaus',
          description: 'Parque Rio Amazonas'
        }
      }
    }
  })
  // Comentário no post
  await prisma.comment.create({
    data: {
      content: 'Ótimo post!',
      userId: userB.id,
      postId: post.id
    }
  })

  console.log('Seed executada com sucesso!')
}

main()
  .catch((e) => {
    console.error("Erro no seed:", e);
    process.exit(1);
  })
  .finally(() => {
    prisma.$disconnect();
    console.log("Seed concluído!");
  });
